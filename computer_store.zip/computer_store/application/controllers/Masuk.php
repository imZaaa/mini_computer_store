<?php
    class Masuk extends CI_Controller {
        public function __construct()
        {
            parent::__construct();
            $this->load->model('Login_model');
            $this->load->library('session');
        }
        public function index(){
            $this->load->view('uts/login');
        }
        public function proses_login(){
            $username = $this->input->post('username');
            $password = $this->input->post ('password');

            $user = $this->Login_model->cek_login($username, $password);

            if($user){
                $data_session = array(
                    'nama_lengkap' => $user->nama_lengkap,
                    'status' => $user->status,
                    'username' => $user->username
                );
                $this->session->set_userdata($data_session);
                echo '<script>alert("Selamat datang ' . $user->nama_lengkap . '");</script>';
                echo '<script>window.location.href="' . site_url('Welcome/home') . '";</script>';
            } else {
                echo '<script>alert("Login gagal!");</script>';
                echo '<script>window.location.href="' . site_url('Masuk') . '";</script>';
            }
        }

        public function logout(){
            $this->session->sess_destroy();
            Redirect('Masuk');
        }

        public function forgot_password()
{
    $email = $this->input->post('email');
    $this->load->model('User_model'); // Pastikan nama model benar
    $user = $this->User_model->get_user_by_email($email);

    if ($user) {
        // Jika email ditemukan, tampilkan password asli
        $this->session->set_flashdata('message', '<div class="alert alert-success">Your password is: ' . $user->password . '</div>');
    } else {
        // Jika email tidak ditemukan, tampilkan pesan error
        $this->session->set_flashdata('message', '<div class="alert alert-danger">Email not registered.</div>');
    }

    redirect('Masuk');
}

    }
?>
