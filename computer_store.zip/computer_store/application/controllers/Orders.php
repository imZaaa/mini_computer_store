<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Orders extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('session');  // Memuat pustaka session
        $this->load->model('Orders_model');  // Memuat model Orders_model
        $this->load->model('Login_model');
    }

    

    // Method untuk insert order
    public function add()
    {
        $user_id = $this->session->userdata('user_id'); // Ambil user_id dari session
        $product_id = $this->input->post('product_id');
    
        // Ambil harga produk dari database
        $this->load->model('Orders_model');
        $product = $this->Orders_model->get_product_by_id($product_id);
    
        if (!$product) {
            $this->session->set_flashdata('error', 'Produk tidak ditemukan.');
            redirect('Orders/list');
            return;
        }
    
        $quantity = 1; // Default quantity
        $total_price = $product['price'] * $quantity; // Hitung total harga
    
        $data = [
            'user_id' => $user_id,
            'product_id' => $product_id,
            'quantity' => $quantity,
            'total_price' => $total_price,
        ];
    
        if ($this->Orders_model->insert_order($data)) {
            $this->session->set_flashdata('success', 'Pesanan berhasil ditambahkan.');
        } else {
            $this->session->set_flashdata('error', 'Gagal menambahkan pesanan.');
        }
    
        redirect('Orders/list');
    }
    
    public function edit_order($id)
{
    $this->load->model('Orders_model');
    $order = $this->Orders_model->get_order_by_id($id);
    $products = $this->Orders_model->get_all_products();

    if (!$order) {
        $this->session->set_flashdata('error', 'Pesanan tidak ditemukan.');
        redirect('orders/list');
    }

    $data['order'] = $order;
    $data['products'] = $products;

    $this->load->view('uts/edit', $data);
}

    
    

public function update_order()
{
    $id = $this->input->post('id');
    $product_id = $this->input->post('product_id');
    $quantity = $this->input->post('quantity');

    // Ambil harga produk dari database
    $this->load->model('Orders_model');
    $product = $this->Orders_model->get_product_by_id($product_id);

    if (!$product) {
        $this->session->set_flashdata('error', 'Produk tidak ditemukan.');
        redirect('Orders/list');
        return;
    }

    $total_price = $product['price'] * $quantity; // Hitung ulang total harga

    $data = [
        'product_id' => $product_id,
        'username' => $username,
        'quantity' => $quantity,
        'total_price' => $total_price,
    ];

    if ($this->Orders_model->update_order($id, $data)) {
        $this->session->set_flashdata('success', 'Pesanan berhasil diperbarui.');
    } else {
        $this->session->set_flashdata('error', 'Gagal memperbarui pesanan.');
    }

    redirect('Orders/list');
}

    
     // Method untuk menghapus order
     public function delete_order($id)
     {
         // Menghapus data order dengan ID yang diberikan
         if ($this->Orders_model->delete_order($id)) {
             $this->session->set_flashdata('success', 'Pesanan berhasil dihapus.');
         } else {
             $this->session->set_flashdata('error', 'Gagal menghapus pesanan.');
         }
 
         // Redirect ke halaman daftar order setelah proses hapus
         redirect('Orders/list');
     }

    public function list()
{
    $data['orders'] = $this->Orders_model->get_all_orders(); // Pastikan `get_all_orders` ada di model
    $this->load->model('Login_model');
    $data['users'] = $this->Login_model->get_all_users();
    $this->load->view('uts/list', $data);
}

    
}
?>
