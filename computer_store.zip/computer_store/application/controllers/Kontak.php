<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kontak extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->library('session');
        // Load model kontak
        $this->load->model('Kontak_model');
    }

    // Menampilkan form kontak
    public function kontak()
    {
        $this->load->view('uts/kontak');
    }

    // Menangani pengiriman form
    public function submit()
    {
        // Mengatur aturan validasi form
        $this->form_validation->set_rules('nama', 'Nama', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('pesan', 'Pesan', 'required');
    
        // Memeriksa apakah form valid
        if ($this->form_validation->run() == FALSE) {
            // Jika validasi gagal, kembali ke halaman form
            $this->load->view('uts/kontak');
        } else {
            // Jika validasi berhasil, simpan data ke database atau proses lebih lanjut
            $nama = $this->input->post('nama');
            $email = $this->input->post('email');
            $pesan = $this->input->post('pesan');
    
            // Menyimpan data ke database
            $data = array(
                'nama' => $nama,
                'email' => $email,
                'pesan' => $pesan
            );
            $this->Kontak_model->insert($data);
    
            // Menampilkan pesan sukses dan kembali ke halaman kontak
            $this->session->set_flashdata('success', 'Pesan berhasil dikirim');
            redirect('Kontak/kontak');
        }
    }
    
}
