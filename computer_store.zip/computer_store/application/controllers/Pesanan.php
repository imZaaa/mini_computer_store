<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pesanan extends CI_Controller {

    // Konstruktor untuk memuat model yang dibutuhkan
    public function __construct()
    {
        parent::__construct();
        // Memuat model untuk pesanan dan produk
        $this->load->model('Order');
        $this->load->model('Product_model');
    }

    // Method untuk menampilkan halaman daftar pesanan
    public function index()
    {
        // Mengambil data pesanan dari database
        $data['Orders'] = $this->Order_model->get_all_orders();
        
        // Mengambil data produk untuk dropdown pada modal edit
        $data['Products'] = $this->Product_model->get_all_products();

        // Memuat view daftar pesanan
        $this->load->view('Orders/list', $data);
    }

    // Method untuk menampilkan form tambah pesanan
    public function add()
    {
        // Mengambil data produk untuk dropdown
        $data['Products'] = $this->Product_model->get_all_products();
        
        // Memuat view untuk form tambah pesanan
        $this->load->view('Orders/add', $data);
    }

    // Method untuk menyimpan pesanan baru ke database
    public function store()
    {
        // Ambil data dari form
        $product_id = $this->input->post('product_id');
        $price = $this->input->post('price');
        $quantity = $this->input->post('quantity');

        // Membuat array data untuk disimpan ke database
        $data = array(
            'product_id' => $product_id,
            'price' => $price,
            'quantity' => $quantity,
            'created_at' => date('Y-m-d')
        );

        // Simpan data pesanan
        $this->Order->insert_order($data);

        // Set flash message untuk feedback
        $this->session->set_flashdata('success', 'Pesanan berhasil ditambahkan.');

        // Redirect kembali ke halaman daftar pesanan
        redirect('uts/list');
    }

    // Method untuk menampilkan form edit pesanan
    public function edit_order($id) {
        // Ambil data order berdasarkan id
        $order = $this->Order_model->get_order_by_id($id);
        
        // Ambil semua data produk dari model
        $products = $this->Product_model->get_all_products();
    
        // Kirim data order dan produk ke view
        $data['Order'] = $order;
        $data['Products'] = $products;  // Pastikan data produk dikirim
        $this->load->view('order_edit', $data);
    }
    
    

    public function update_order() {
        // Ambil data dari form
        $id = $this->input->post('id');
        $title = $this->input->post('title');
        $price = $this->input->post('price');
        $quantity = $this->input->post('quantity');
        
        // Update data order
        $this->Order_model->update_order($id, $title, $price, $quantity);

        // Redirect ke daftar pesanan dengan pesan sukses
        $this->session->set_flashdata('success', 'Pesanan berhasil diperbarui!');
        redirect('Orders/list');
    }
}

?>