<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Products extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Product_model'); // Memuat model Product_model
    }

    // Menampilkan daftar produk
    public function index()
    {
        // Mengambil data produk dari model
        $data['products'] = $this->Product_model->get_all_products();

        // Menampilkan data produk di view
        $this->load->view('uts/home', $data);
    }
}
?>
