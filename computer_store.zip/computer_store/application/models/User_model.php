<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class User_model extends CI_Model{
    public function get_user_by_email($email)
{
    return $this->db->get_where('login', ['email' => $email])->row(); // Ganti 'users' dengan nama tabel Anda
}

}

?>
