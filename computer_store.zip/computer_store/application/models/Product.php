<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Model {

    // Mengambil semua data produk
    public function get_all_products()
    {
        $query = $this->db->get('Products');
        return $query->result_array();
    }

    // Mengambil produk berdasarkan ID
    public function get_product_by_id($id)
    {
        $query = $this->db->get_where('Products', array('id' => $id));
        return $query->row_array();
    }
}
