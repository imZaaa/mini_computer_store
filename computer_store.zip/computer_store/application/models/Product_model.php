<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product_model extends CI_Model {

    public function __construct()
    {
        parent::__construct();
        $this->load->database(); // Pastikan database diload di konstruktor model
    }

    // Method untuk mengambil semua produk
    public function get_all_products() {
        return $this->db->get('Products')->result_array();
    }
}
