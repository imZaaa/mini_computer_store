<?php
    Class Login_model extends CI_Model{
        public function __construct()
        {
            parent::__construct();
            $this->load->database();
        }

        public function cek_login($username, $password){
            // Query untuk mengecek username, password, dan email
            $this->db->where('username', $username);
            $this->db->where('password', $password); // Pastikan menggunakan enkripsi password jika diperlukan
        
            $query = $this->db->get('login'); // Sesuaikan dengan nama tabel Anda
          
            if($query->num_rows() > 0){
                return $query->row(); // Kembalikan data pengguna jika ditemukan
            } else {
                return false; // Jika tidak ada data yang cocok
            }
        }

        public function get_all_users()
        {
            return $this->db->get('login')->result_array(); // Ambil semua data dari tabel login
        }
        
    }
?>