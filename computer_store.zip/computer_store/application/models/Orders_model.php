<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Orders_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database(); // Pastikan database sudah terload
    }

    // Fungsi untuk menyimpan data order
    public function insert_order($data)
{
    $this->db->insert('Orders', $data);
    return $this->db->affected_rows() > 0;
}


    // Fungsi untuk mendapatkan semua pesanan
    public function get_all_orders()
    {
        $this->db->select('Orders.*, Products.title, Products.price, Products.image, 
                           (Products.price * Orders.quantity) as total_price'); // Hitung total harga
        $this->db->from('Orders');
        $this->db->join('Products', 'Orders.product_id = Products.id', 'left');
        $query = $this->db->get();
    
        return $query->result_array();
    }
    

    // Fungsi untuk memperbarui data pesanan
    public function update_order($id, $data)
    {
        $this->db->where('id', $id);
        return $this->db->update('Orders', $data);
    }

    // Fungsi untuk menghapus pesanan
    public function delete_order($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete('Orders');
    }

    // Fungsi untuk mendapatkan pesanan berdasarkan ID
    public function get_order_by_id($id)
    {
        $this->db->select('Orders.*, Products.title as product_title, Products.price as product_price, Products.image');
        $this->db->from('Orders');
        $this->db->join('Products', 'Orders.product_id = Products.id', 'left');
        $this->db->where('Orders.id', $id);
        $query = $this->db->get();

        return $query->row_array(); // Mengembalikan satu baris data
    }

    // Fungsi untuk mendapatkan semua produk
    public function get_all_products()
    {
        $this->db->select('*');
        $this->db->from('Products');
        $this->db->order_by('title', 'ASC'); // Urutkan produk berdasarkan abjad
        $query = $this->db->get();

        return $query->result_array();
    }

    // Fungsi untuk menghitung total harga berdasarkan product_id dan quantity
    public function calculate_total_price($product_id, $quantity)
    {
        $product = $this->get_product_by_id($product_id);

        if ($product) {
            return $product['price'] * $quantity;
        }
        return 0; // Kembalikan 0 jika produk tidak ditemukan
    }

    // Fungsi untuk mendapatkan detail produk berdasarkan ID
    public function get_product_by_id($product_id)
    {
        $this->db->select('*');
        $this->db->from('Products');
        $this->db->where('id', $product_id);
        $query = $this->db->get();

        return $query->row_array();
    }
}
