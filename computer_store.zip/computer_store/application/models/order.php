<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Order extends CI_Model {

    // Mengambil semua data pesanan
     // Fungsi untuk mengambil data produk
     public function get_all_products() {
        $query = $this->db->get('products');
        $result = $query->result_array();  // Mengembalikan data produk
        var_dump($result);  // Periksa apakah data produk ada
        exit;
        return $result;
    }

    // Fungsi untuk mengambil data order berdasarkan ID
    public function get_order_by_id($id) {
        $query = $this->db->get_where('orders', ['id' => $id]);
        return $query->row_array();  // Mengembalikan data order
    }

    public function update_order($id, $title, $price, $quantity) {
        $data = [
            'title' => $title,
            'price' => $price,
            'quantity' => $quantity
        ];

        $this->db->where('id', $id);
        $this->db->update('Orders', $data);
    }
 
    
}
?>
