<?php
    $nama_lengkap = $this->session->userdata('nama_lengkap');
    $status = $this->session->userdata('status');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <title>Home</title>
    <style>
        /* Custom style for navbar links */
        .navbar-nav .nav-link {
            color: #f54242;
            font-weight: 500;
            margin-right: 1rem;
            transition: color 0.3s ease, transform 0.2s ease;
        }
        
        .navbar-nav .nav-link:hover {
            color: #ffffff;
            transform: scale(1.1);
        }

        .btn-login {
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        .btn-login:hover {
            background-color: #f54242;
            transform: scale(1.05);
        }

        /* Carousel custom styling */
        .carousel-container {
            padding-top: 68px; /* Adjust padding based on navbar height */
        }

        .carousel-item img {
            height: 500px;
            object-fit: cover;
            object-position: center;
        }

        /* Smooth transition effect for carousel */
        .carousel-inner {
            transition: transform 0.5s ease-in-out;
        }

/* Menyembunyikan scrollbar standar */
::-webkit-scrollbar {
    width: 8px; /* Lebar scrollbar saat tidak hover */
    height: 8px; /* Tinggi scrollbar horizontal saat tidak hover */
    transition: width 0.3s ease, height 0.3s ease; /* Transisi untuk ukuran scrollbar */
}

/* Styling track (area kosong di scrollbar) */
::-webkit-scrollbar-track {
    background: #f1f1f1; /* Warna latar belakang track */
    border-radius: 10px; /* Membulatkan sudut track */
}

/* Styling handle (bagian yang bisa digeser) */
::-webkit-scrollbar-thumb {
    background: #f54242; /* Warna handle scrollbar */
    border-radius: 10px; /* Membulatkan sudut handle */
    border: 3px solid #f1f1f1; /* Memberikan border pada handle */
    transition: background-color 0.3s ease; /* Transisi untuk perubahan warna handle */
}

/* Efek hover pada scrollbar thumb */
::-webkit-scrollbar-thumb:hover {
    background: #e53935; /* Warna ketika mouse hover di atas handle */
}

/* Mengubah ukuran scrollbar hanya saat hover */
::-webkit-scrollbar:hover {
    width: 12px; /* Lebar scrollbar yang lebih besar saat hover */
    height: 12px; /* Tinggi scrollbar horizontal yang lebih besar saat hover */
}


    /* Gaya untuk card */
      /* Gaya untuk card */
      .card {
        background: linear-gradient(135deg, #ffffff, #f8f9fa); /* Gradasi ringan */
        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1), 0 2px 4px rgba(0, 0, 0, 0.06);
        border: none;
        border-radius: 15px;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        overflow: hidden;
    }

    /* Efek hover pada card */
    .card:hover {
        transform: translateY(-5px); /* Efek mengangkat */
        box-shadow: 0 12px 24px rgba(0, 0, 0, 0.15), 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    /* Gaya untuk gambar di dalam card */
    .card-img-top {
        transition: transform 0.3s ease, filter 0.3s ease;
        filter: brightness(0.95); /* Sedikit gelap untuk efek elegan */
    }

    /* Efek zoom dan filter pada gambar */
    .card:hover .card-img-top {
        transform: scale(1.05); /* Zoom in */
        filter: brightness(1); /* Kembali normal saat hover */
    }

    /* Gaya untuk judul */
    /* Gaya untuk judul di dalam card */
    .card-title {
        font-family: 'Playfair Display', serif; /* Font elegan */
        font-size: 1.2rem; /* Ukuran yang lebih proporsional */
        font-weight: bold;
        color: #e63946; /* Warna merah yang lebih lembut */
        text-align: center;
        margin-bottom: 10px;
        text-transform: capitalize; /* Awal kata kapital untuk kesan rapi */
    }

    /* Gaya untuk teks harga */
    .card-text {
        font-family: 'Roboto', sans-serif; /* Font modern dan bersih */
        font-size: 0.95rem; /* Sedikit lebih kecil untuk menghemat ruang */
        font-weight: 400;
        color: #495057; /* Warna abu-abu yang tidak terlalu gelap */
        text-align: center;
        margin-bottom: 15px;
        line-height: 1.5; /* Spasi antar baris */
    }

    /* Gaya untuk teks deskripsi tambahan di bawah harga */
    .card-description {
        font-size: 0.85rem; /* Lebih kecil untuk info tambahan */
        font-style: italic;
        color: #6c757d; /* Abu-abu terang */
        text-align: center;
        margin-bottom: 10px;
    }

    /* Efek hover pada teks */
    .card:hover .card-title, 
    .card:hover .card-text {
        color: #dc3545; /* Merah gelap pada hover */
        transition: color 0.3s ease;
    }

    /* Responsivitas untuk layar kecil */
    @media (max-width: 576px) {
        .card-title {
            font-size: 1rem; /* Ukuran lebih kecil di layar kecil */
        }

        .card-text {
            font-size: 0.85rem; /* Menyesuaikan teks harga */
        }

        .card-description {
            font-size: 0.75rem; /* Deskripsi juga lebih kecil */
        }

    /* Gaya untuk tombol */
    .btn-danger {
        background-color: #dc3545;
        border: none;
        border-radius: 50px; /* Membulatkan tombol */
        padding: 10px 20px;
        font-family: 'Roboto', sans-serif;
        font-weight: bold;
        transition: background-color 0.3s ease, transform 0.2s ease;
    }

    .btn-danger:hover {
        background-color: #bb2d3b;
        transform: scale(1.05); /* Sedikit memperbesar tombol */
    }

    /* Animasi tombol di bagian bawah */
    .btn-danger::after {
        content: '';
        display: block;
        width: 0;
        height: 2px;
        background: #f54242;
        transition: width 0.3s;
    }

    .btn-danger:hover::after {
        width: 100%; /* Garis penuh saat hover */
        transition: width 0.3s;
    }
    }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand text-danger fw-bolder fst-italic fs-3 ms-5" href="#">TechNest</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent" aria-controls="navbarContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarContent">
                <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= site_url('Orders/list')?>">Pesanan</a>
                    </li>
                </ul>
                                <!-- Button trigger modal -->
                    <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#exampleModal">
                    <i class="bi bi-person-circle"></i>
                    </button>         
               
            </div>
        </div>
</nav>
    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Info Account</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <center><h5>Anda login sebagai <br> <?= $nama_lengkap . " | | " .  $status ;?></h5></center>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <a href="<?= site_url('Masuk/logout') ?>" class="btn btn-danger">Logout</a>
                        </div>
                        </div>
                    </div>
                    </div>
    <!-- Carousel with padding-top to avoid navbar overlap --> 
    <div class="carousel-container">
        <div id="carouselExampleAutoplaying" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="<?= base_url('assets/home1.jpg') ?>" class="d-block w-100" alt="Slide 1">
                </div>
                <div class="carousel-item">
                    <img src="<?= base_url('assets/home2.jpg') ?>" class="d-block w-100" alt="Slide 2">
                </div>
                <div class="carousel-item">
                    <img src="<?= base_url('assets/home3.jpg') ?>" class="d-block w-100" alt="Slide 3">
                </div>
                <div class="carousel-item">
                    <img src="<?= base_url('assets/home4.jpg') ?>" class="d-block w-100" alt="Slide 4">
                </div>
            </div>
        </div>
    </div>

    <br>
    <br><br>
    <div class="container text-center my-5" id="produk">
        <h2 class="display-4 text-danger fw-bold" style="font-family: 'Arial', sans-serif;">Best Seller</h2>
        <p class="lead text-muted">Explore the most popular products we have to offer!</p>
    </div>

    <div class="container mt-4">
    <div class="row">
    <?php foreach ($products as $product) : ?>
        <div class="col-md-4 mb-4">
            <div class="card h-100 d-flex flex-column">
                <!-- Gambar -->
                <img src="<?php echo base_url('assets/' . $product['image']); ?>" class="card-img-top" alt="<?php echo $product['title']; ?>" style="height: 200px; object-fit: cover;">
                
                <!-- Konten Card -->
                <div class="card-body d-flex flex-column">
                    <h5 class="card-title fw-bold fst-italic">
                        <?php echo $product['title']; ?>
                    </h5>
                    <div class="row">
                        <div class="col-sm-4">
                    <p class="card-text">
                        <strong>Category:</strong> <?php echo $product['category']; ?>
                    </p>
                    </div>
                    <div class="col-sm-8">
                    <p class="card-text">
                        <strong>Harga:</strong> Rp.<?php echo number_format($product['price'], 0, ',', '.'); ?>
                    </p>
                    </div>
                    <div class="col-sm-6">
                    <p class="card-description">
                    <?php echo $product['rate']; ?>
                    </p>
                    </div>
                    <div class="col-sm-6">
                    <p class="card-description">
                        *Best Offer*
                    </p>
                    </div>
                    </div>
                    <div class="mt-auto">
                        <form action="<?php echo site_url('Orders/add'); ?>" method="post">
                            <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                            <button type="submit" class="btn btn-danger w-100">
                                Tambahkan ke Pesanan
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>
</div>

<!-- Footer -->
<footer class="bg-dark text-white py-4">
    <div class="container">
        <div class="row">
            <!-- Tentang Kami -->
            <div class="col-md-4 mb-3">
                <h5 class="text-danger fw-bold">Tentang TechNest</h5>
                <p class="small">
                    TechNest adalah platform untuk kebutuhan teknologi Anda. Kami menyediakan berbagai produk berkualitas dengan penawaran terbaik.
                </p>
            </div>

            <!-- Navigasi Cepat -->
            <div class="col-md-4 mb-3">
                <h5 class="text-danger fw-bold">Navigasi</h5>
                <ul class="list-unstyled">
                    <li><a href="#" class="text-white text-decoration-none">Home</a></li>
                    <li><a href="<?= site_url('Orders/list') ?>" class="text-white text-decoration-none">Pesanan</a></li>
                </ul>
            </div>

            <!-- Ikuti Kami -->
            <div class="col-md-4 mb-3">
                <h5 class="text-danger fw-bold">Ikuti Kami</h5>
                <div>
                    <a href="#" class="text-white me-3"><i class="bi bi-facebook"></i></a>
                    <a href="#" class="text-white me-3"><i class="bi bi-twitter"></i></a>
                    <a href="#" class="text-white me-3"><i class="bi bi-instagram"></i></a>
                    <a href="#" class="text-white"><i class="bi bi-youtube"></i></a>
                </div>
            </div>
        </div>

        <!-- Hak Cipta -->
        <div class="text-center mt-3">
            <p class="small mb-0">&copy; 2024 TechNest. Semua Hak Dilindungi.</p>
        </div>
    </div>
</footer>


        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

