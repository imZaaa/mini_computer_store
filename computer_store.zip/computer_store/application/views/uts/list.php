<?php
    $nama_lengkap = $this->session->userdata('nama_lengkap');
    $status = $this->session->userdata('status');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Pesanan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


    <style>
          .navbar-nav .nav-link {
            color: #f54242;
            font-weight: 500;
            margin-right: 1rem;
            transition: color 0.3s ease, transform 0.2s ease;
        }
        
        .navbar-nav .nav-link:hover {
            color: #ffffff;
            transform: scale(1.1);
        }

        .btn-login {
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        .btn-login:hover {
            background-color: #f54242;
            transform: scale(1.05);
        }
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 50px;
        }
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .alert {
            border-radius: 10px;
        }
        .table thead th {
            background-color: #B22222;
            color: white;
        }
        .table tbody tr:hover {
            background-color: #f1f1f1;
        }
        .img-fluid {
            border-radius: 5px;
        }
        .date-column {
            white-space: nowrap; /* Mencegah pemecahan baris pada tanggal */
        }

        /* Menyembunyikan scrollbar standar */
::-webkit-scrollbar {
    width: 8px; /* Lebar scrollbar saat tidak hover */
    height: 8px; /* Tinggi scrollbar horizontal saat tidak hover */
    transition: width 0.3s ease, height 0.3s ease; /* Transisi untuk ukuran scrollbar */
}

/* Styling track (area kosong di scrollbar) */
::-webkit-scrollbar-track {
    background: #f1f1f1; /* Warna latar belakang track */
    border-radius: 10px; /* Membulatkan sudut track */
}

/* Styling handle (bagian yang bisa digeser) */
::-webkit-scrollbar-thumb {
    background: #f54242; /* Warna handle scrollbar */
    border-radius: 10px; /* Membulatkan sudut handle */
    border: 3px solid #f1f1f1; /* Memberikan border pada handle */
    transition: background-color 0.3s ease; /* Transisi untuk perubahan warna handle */
}

/* Efek hover pada scrollbar thumb */
::-webkit-scrollbar-thumb:hover {
    background: #e53935; /* Warna ketika mouse hover di atas handle */
}

/* Mengubah ukuran scrollbar hanya saat hover */
::-webkit-scrollbar:hover {
    width: 12px; /* Lebar scrollbar yang lebih besar saat hover */
    height: 12px; /* Tinggi scrollbar horizontal yang lebih besar saat hover */
}
    </style>
</head>
<body>
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand text-danger fw-bolder fst-italic fs-3 ms-5" href="#">TechNest</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent" aria-controls="navbarContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarContent">
                <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link"href="<?= site_url('Welcome/home')?>">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page"  href="# ">Pesanan</a>
                    </li>
                </ul>
                <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#exampleModal">
                    <i class="bi bi-person-circle"></i>
                    </button>         
               
            </div>
        </div>
</nav>
    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Info Account</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <center><h5>Anda login sebagai <br> <?= $nama_lengkap . " | | " .  $status ;?></h5></center>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <a href="<?= site_url('Masuk/logout') ?>" class="btn btn-danger">Logout</a>
                        </div>
                        </div>
                    </div>
                    </div>
<br> <br>
<div class="container-fluid my-5">
    <div class="card">
        <div class="card-body">
            <h2 class="text-center mt-3 mb-4 text-danger">Daftar Pesanan</h2>

            <script>
                <?php if ($this->session->flashdata('success')) : ?>
                    Swal.fire({
                        icon: 'success',
                        title: 'Berhasil!',
                        text: '<?php echo $this->session->flashdata('success'); ?>',
                        confirmButtonText: 'OK',
                        timer: 3000 // Otomatis menutup setelah 3 detik
                    });
                <?php elseif ($this->session->flashdata('error')) : ?>
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: '<?php echo $this->session->flashdata('error'); ?>',
                        confirmButtonText: 'OK',
                        timer: 3000 // Otomatis menutup setelah 3 detik
                    });
                <?php endif; ?>
            </script> 
            <a href="<?= site_url('Welcome/home#produk'); ?>" class="btn btn-danger text-decoration-none text-white mb-3">Tambah Pesanan</a>
            <a href="<?= site_url('Welcome/home') ?>" class="btn btn-danger mb-3">Back</a>


            <table class="table table-bordered table-striped text-center">
                <thead class="thead-dark">
                    <tr>
                        <th style="width: 80px;">ID</th>
                        <th>Gambar</th>
                        <th style="width: 350px;">Nama Produk</th>
                        <th>Nama Pemesan</th>
                        <th style="width: 200px;">Harga</th>
                        <th>Jumlah</th>
                        <th>Total</th>
                        <th>Tanggal Pesan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
    <?php if (!empty($orders)) : ?>
        <?php foreach ($orders as $index => $order) : ?>
            <tr>
                <td><?php echo "ORD-" . ($index + 1); ?></td>
                <td>
                    <img src="<?php echo base_url('assets/' . $order['image']); ?>" 
                         alt="<?php echo $order['title']; ?>" 
                         class="img-fluid" 
                         style="width: 80px; height: auto;">
                </td>
                <td><?php echo $order['title']; ?></td>
                <td><?=$nama_lengkap?> </td>
                <td>Rp. <?php echo number_format($order['price'], 0, ',', '.'); ?></td>
                <td><?php echo $order['quantity']; ?></td>
                <td>Rp. <?php echo number_format($order['total_price'], 0, ',', '.'); ?></td> <!-- Total Harga -->
                <td><?php echo date('d-m-Y', strtotime($order['created_at'])); ?></td> <!-- Tanggal Pembayaran -->              
                <td>
                    <a href="<?= site_url('orders/edit_order/' . $order['id']) ?>" class="btn btn-warning btn-sm">
                        <i class="bi bi-pencil-square"></i>
                    </a>
                    <a href="<?= site_url('orders/delete_order/' . $order['id']) ?>" class="btn btn-danger btn-sm" onclick="return confirmDelete(event, '<?= $order['id'] ?>')">
                        <i class="bi bi-trash"></i>
                    </a>
                    <script>
                        function confirmDelete(event, orderId) {
                            event.preventDefault();  // Mencegah aksi default (redirect ke link)
                            
                            Swal.fire({
                                icon: 'warning',
                                title: 'Apakah Anda yakin?',
                                text: "Pesanan ini akan dihapus!",
                                showCancelButton: true,
                                confirmButtonText: 'Ya, Hapus',
                                cancelButtonText: 'Batal',
                            }).then((result) => {
                                if (result.isConfirmed) {
                                    // Jika user mengkonfirmasi, redirect ke URL untuk hapus pesanan
                                    window.location.href = "<?= site_url('orders/delete_order/') ?>" + orderId;
                                }
                            });
                        }
                    </script>
                </td>
            </tr>
        <?php endforeach; ?>
    <?php else : ?>
        <tr>
            <td colspan="8" class="text-center">Belum ada pesanan.</td>
        </tr>
    <?php endif; ?>
</tbody>

            </table>
        </div>
    </div>
</div>

<!-- Add Modal -->
<div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="addModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addModalLabel">Tambah Pesanan</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo base_url('add.php'); ?>" method="POST" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="title">Nama Produk</label>
                        <input type="text" class="form-control" id="title" name="title" required>
                    </div>
                    <div class="form-group">
                        <label for="price">Harga</label>
                        <input type="number" class="form-control" id="price" name="price" required>
                    </div>
                    <div class="form-group">
                        <label for="quantity">Jumlah</label>
                        <input type="number" class="form-control" id="quantity" name="quantity" required>
                    </div>
                    <div class="form-group">
                        <label for="image">Gambar</label>
                        <input type="file" class="form-control" id="image" name="image" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-primary">Tambah</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editModalLabel">Edit Pesanan</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?= site_url('orders/update_order') ?>" method="POST">
                <input type="hidden" name="id" value="<?= $order['id'] ?>">
                <div class="modal-body">
                    <!-- Dropdown untuk memilih nama produk -->
                            <div class="form-group">
            <label for="edit-product">Nama Produk</label>
            <select class="form-control" id="edit-product" name="product_id" required>
                <?php if (!empty($orders)): ?>
                    <?php foreach ($orders as $order): ?>
                        <option value="<?= $order['id'] ?>" <?= ($order['product_id'] == $order['id']) ? 'selected' : '' ?>>
                            <?= $order['title'] ?>
                        </option>
                    <?php endforeach; ?>
                <?php else: ?>
                    <option value="">Tidak ada produk</option>
                <?php endif; ?>
            </select>
        </div>


                    <!-- Input untuk jumlah produk -->
                    <div class="form-group">
                        <label for="edit-quantity">Jumlah</label>
                        <input type="number" class="form-control" id="edit-quantity" name="quantity" value="<?= $order['quantity'] ?>" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Footer -->
<footer class="bg-dark text-white py-4">
    <div class="container">
        <div class="row">
            <!-- Tentang Kami -->
            <div class="col-md-4 mb-3">
                <h5 class="text-danger fw-bold">Tentang TechNest</h5>
                <p class="small">
                    TechNest adalah platform untuk kebutuhan teknologi Anda. Kami menyediakan berbagai produk berkualitas dengan penawaran terbaik.
                </p>
            </div>

            <!-- Navigasi Cepat -->
            <div class="col-md-4 mb-3">
                <h5 class="text-danger fw-bold">Navigasi</h5>
                <ul class="list-unstyled">
                    <li><a href="#" class="text-white text-decoration-none">Home</a></li>
                    <li><a href="<?= site_url('Orders/list') ?>" class="text-white text-decoration-none">Pesanan</a></li>
                </ul>
            </div>
            <!-- Ikuti Kami -->
            <div class="col-md-4 mb-3">
                <h5 class="text-danger fw-bold">Ikuti Kami</h5>
                <div>
                    <a href="#" class="text-white me-3"><i class="bi bi-facebook"></i></a>
                    <a href="#" class="text-white me-3"><i class="bi bi-twitter"></i></a>
                    <a href="#" class="text-white me-3"><i class="bi bi-instagram"></i></a>
                    <a href="#" class="text-white"><i class="bi bi-youtube"></i></a>
                </div>
            </div>
        </div>

        <!-- Hak Cipta -->
        <div class="text-center mt-3">
            <p class="small mb-0">&copy; 2024 TechNest. Semua Hak Dilindungi.</p>
        </div>
    </div>
</footer>


<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>


</body>
</html>
