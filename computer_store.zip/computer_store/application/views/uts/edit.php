<?php
if (!isset($order)) {
    echo "Data tidak ditemukan.";
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Pesanan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f7f7f7;
            font-family: 'Arial', sans-serif;
        }
        .container {
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 40px;
            max-width: 600px; /* Agar form tidak terlalu lebar */
            margin: auto;
        }
        h2 {
            font-size: 2rem;
            font-weight: bold;
            color: #d9534f;
        }
        .form-label {
            font-weight: bold;
            color: #333;
        }
        .btn-danger {
            background-color: #d9534f;
            border: none;
            transition: background-color 0.3s;
            padding: 10px 30px;
        }
        .btn-danger:hover {
            background-color: #c9302c;
        }
        .btn-secondary {
            background-color: #6c757d;
            border: none;
            transition: background-color 0.3s;
            padding: 10px 30px;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
        }
        .form-select, .form-control {
            border-radius: 8px;
            border: 1px solid #ddd;
            padding: 10px;
        }
        .form-control:focus, .form-select:focus {
            border-color: #d9534f;
            box-shadow: 0 0 5px rgba(217, 83, 79, 0.5);
        }
        .btn-wrapper {
            display: flex;
            justify-content: space-between;
            gap: 10px;
        }
        .btn-wrapper .btn {
            width: 48%; /* Tombol dengan lebar yang lebih kecil */
        }
        .form-control, .form-select {
            font-size: 1rem;
        }
        .form-group {
            margin-bottom: 1.5rem;
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <h2 class="text-center mb-4">Edit Pesanan</h2>
    <form action="<?= site_url('orders/update_order') ?>" method="POST">
        <input type="hidden" name="id" value="<?= $order['id'] ?>">
        
        <!-- Nama Produk -->
        <div class="mb-3">
            <label for="title" class="form-label">Nama Produk</label>
            <select class="form-select" id="title" name="product_id" required>
                <?php foreach ($products as $product): ?>
                    <option value="<?= $product['id'] ?>" <?= ($order['product_id'] == $product['id']) ? 'selected' : '' ?>>
                        <?= $product['title'] ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        
        <!-- Jumlah -->
        <div class="mb-3">
            <label for="quantity" class="form-label">Jumlah</label>
            <input type="number" class="form-control" id="quantity" name="quantity" value="<?= $order['quantity'] ?>" required>
        </div>
        
        <!-- Tombol Simpan dan Kembali -->
        <div class="btn-wrapper">
            <button type="submit" class="btn btn-danger">Simpan Perubahan</button>
            <a href="<?= site_url('orders/list') ?>" class="btn btn-secondary">Kembali</a>
        </div>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
